AddCSLuaFile()

local nading = false

concommand.Add("+quicknade", function() 

    local ply = LocalPlayer()

	if ply:GetAmmoCount( 10 ) <= 0 or ply:GetActiveWeapon():GetClass() == "weapon_frag" then
	    LocalPlayer():EmitSound("player/suit_denydevice.wav") return
    end
	
    if VManip:PlayAnim("thrownade") then
	    timer.Simple(0.1, function() if VManip:GetCurrentAnim()=="thrownade" then
	        net.Start("VManip_Nade")
	        net.SendToServer()
	        LocalPlayer():EmitSound("vmanip/grenade_pin_frag.wav") 
		end
	    end)
	
	    nading = true
    end
end)

concommand.Add("-quicknade",function() 

    if nading and VManip:IsActive() then
	
        nading=false
		
        VManip:QuitHolding("thrownade")
        timer.Simple(math.Clamp(VManip.HoldTime-CurTime(),0,2)+0.2,function() net.Start("VManip_NadeThrow") net.SendToServer() end)
        timer.Simple(0.15, function() if VManip:GetCurrentAnim()=="thrownade" and nading == false then
	        LocalPlayer():EmitSound("vmanip/grenade_frag_throw.wav")
	    end
	    end) 
    end
end)
  
net.Receive("VManip_NadeBlowHands",function(len)
    if VManip:GetCurrentAnim()=="thrownade" then VManip:Remove() end
end)